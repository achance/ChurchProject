Cufon.replace('#menu a, .banner, h2, h3, h4, .button2, #footer_logo, .tel, .nav a', { fontFamily: 'Vegur', hover:true });
Cufon.replace('.pagination a', { fontFamily: 'Vegur', hover:true, textShadow:'rgba(0, 0, 0, .1) 1px 1px' });
